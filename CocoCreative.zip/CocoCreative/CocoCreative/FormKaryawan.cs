﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CocoCreative
{
    public partial class FormKaryawan : Form
    {
        public FormKaryawan()
        {
            InitializeComponent();
        }

        private void FormKaryawan_Load(object sender, EventArgs e)
        {

        }

       
    }
}
